package com.springjdbctest.in;

import java.util.Scanner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Update {
public static void main(String[] args) {
System.out.println("Enter number of data to be updated - ");
Scanner sc = new Scanner(System.in);
int num = sc.nextInt();
for (int i = 1; i <= num; i++) {
System.out.println("Enter id to be updated- ");
String id = sc.next();
System.out.println("Enter name - ");
String name = sc.next();
System.out.println("Enter age - ");
String age = sc.next();
Student std = new Student(id, name, age);
ClassPathXmlApplicationContext ac = new
ClassPathXmlApplicationContext("ApplicationContext.xml");
StudentDao stdao = (StudentDao) ac.getBean("stdao");
stdao.updateStud(std);
ac.close();
}
sc.close();
System.out.println("UPDATED RECORDS SUCCESSFULLY!!");
}
}
