package com.springjdbctest.in;

import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
public class StudentDao {
	
private JdbcTemplate jdbcTemplate;
//jdbcTemplate is a reference variable

public JdbcTemplate getJdbcTemplate() {
return jdbcTemplate;
}
public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
this.jdbcTemplate = jdbcTemplate;
}
//creating a method for insert the values
public String saveStud(Student s) {
String query = "insert into springjdbc(name,age) values('" +
s.getName() + "','" + s.getAge() + "')";
jdbcTemplate.update(query);
return "success";
}
//view all data
public List<Student> studList() {
List<Student> studList = jdbcTemplate.query("select * from springjdbc",
new StudentRowMapper());
//StudentRowMapper class is used to show all datas in the database.
return studList;
}

public String updateStud(Student s) {
String query = "update springjdbc set name = '" + s.getName() + "',age='"
+ s.getAge() + "' where id = '" + s.getId() + "'";
jdbcTemplate.update(query);
return "success";
}
public String delStud(Student s) {
String query = "delete from springjdbc where id = '" + s.getId() + "'";
jdbcTemplate.update(query);
return "success";
}
}