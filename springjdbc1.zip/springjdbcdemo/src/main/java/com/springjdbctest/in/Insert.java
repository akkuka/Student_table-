package com.springjdbctest.in;

import java.util.Scanner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Insert {
public static void main(String[] args) {
System.out.println("Enter number of data to be inserted - ");
Scanner sc = new Scanner(System.in);
int num = sc.nextInt();
//looping used for inserting the values one by one.
for (int i = 1; i <= num; i++) {
System.out.println("Enter name - ");
String name = sc.next();
System.out.println("Enter age - ");
String age = sc.next();
//creating the constructor using bean class for passing the parameters
Student std = new Student("", name, age);
//"ClassPathXmlApplicationContext" is an inbuilt class which is decided which xml files to connect 
ClassPathXmlApplicationContext ac = new ClassPathXmlApplicationContext("ApplicationContext.xml");
//get bean() method is used to convert normal bean to spring bean.(type casting)
StudentDao stdao = (StudentDao) ac.getBean("stdao");
stdao.saveStud(std);
//std is the reference object of bean class
ac.close();
}
sc.close();
System.out.println("INSERTED RECORDS SUCCESSFULLY!!");
}
}
