package com.springjdbctest.in;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
public class StudentRowMapper implements RowMapper<Student>
//rowMapper is an interface.
{
	//mapRow method is used to map the datas in the database to this page.
public Student mapRow(ResultSet rs, int rowNum) throws SQLException 
{
Student stud = new Student();
stud.setId(rs.getString("id"));
stud.setName(rs.getString("name"));
stud.setAge(rs.getString("age"));
return stud;
}
}
