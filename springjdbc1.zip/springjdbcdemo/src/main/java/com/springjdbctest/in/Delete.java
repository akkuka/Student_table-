package com.springjdbctest.in;

import java.util.Scanner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Delete {
public static void main(String[] args) {
System.out.println("Enter number of data to be deleted - ");
Scanner sc = new Scanner(System.in);
int num = sc.nextInt();
for (int i = 1; i <= num; i++) {
System.out.println("Enter id to be deleted - ");
String id = sc.next();
Student std = new Student(id, "", "");
ClassPathXmlApplicationContext ac = new
ClassPathXmlApplicationContext("ApplicationContext.xml");
StudentDao stdao = (StudentDao) ac.getBean("stdao");
stdao.delStud(std);
ac.close();
}
sc.close();
System.out.println("DELETED RECORDS SUCCESSFULLY!!");
}
}