package com.springjdbctest.in;

import java.util.List;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class View {
public static void main(String[] args) {
ClassPathXmlApplicationContext ac = new
ClassPathXmlApplicationContext("ApplicationContext.xml");

StudentDao stdao = (StudentDao) ac.getBean("stdao");
List<Student> studList = stdao.studList();
for (Student s : studList) {
System.out.print("Id - " + s.getId());
System.out.print(" Name - " + s.getName());
System.out.println(" Age - " + s.getAge());
}
ac.close();
}
}